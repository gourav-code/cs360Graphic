var gl;
var color;
var animation;
var degreeSun = 0;
var degree1 = 0;
var degree2 = 0;
var matrixStack = [];
var animation;
var x_boat = 0.0;
var addValue = 0.003;
var clickedButton = 0;
var drawdiffOutput;

// mMatrix is called the model matrix, transforms objects
// from local object space to world space.
var mMatrix = mat4.create();
var uMMatrixLocation;
var aPositionLocation;
var uColorLoc;
var triangleBuf;
var triangleIndexBuf
var circleBuf;
var circleIndexBuf;
var sqVertexPositionBuffer;
var sqVertexIndexBuffer;

const vertexShaderCode = `#version 300 es
in vec2 aPosition;
uniform mat4 uMMatrix;

void main() {
  gl_Position = uMMatrix*vec4(aPosition,0.0,1.0);
  gl_PointSize = 5.0;
}`;

const fragShaderCode = `#version 300 es
precision mediump float;
out vec4 fragColor;

uniform vec4 color;

void main() {
  fragColor = color;
}`;

function pushMatrix(stack, m) {
  //necessary because javascript only does shallow push
  var copy = mat4.create(m);
  stack.push(copy);
}

function popMatrix(stack) {
  if (stack.length > 0) return stack.pop();
  else console.log("stack has no matrix to pop!");
}

function degToRad(degrees) {
  return (degrees * Math.PI) / 180;
}

function vertexShaderSetup(vertexShaderCode) {
  shader = gl.createShader(gl.VERTEX_SHADER);
  gl.shaderSource(shader, vertexShaderCode);
  gl.compileShader(shader);
  // Error check whether the shader is compiled correctly
  if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
    alert(gl.getShaderInfoLog(shader));
    return null;
  }
  return shader;
}

function fragmentShaderSetup(fragShaderCode) {
  shader = gl.createShader(gl.FRAGMENT_SHADER);
  gl.shaderSource(shader, fragShaderCode);
  gl.compileShader(shader);
  // Error check whether the shader is compiled correctly
  if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
    alert(gl.getShaderInfoLog(shader));
    return null;
  }
  return shader;
}

function initShaders() {
  shaderProgram = gl.createProgram();

  var vertexShader = vertexShaderSetup(vertexShaderCode);
  var fragmentShader = fragmentShaderSetup(fragShaderCode);

  // attach the shaders
  gl.attachShader(shaderProgram, vertexShader);
  gl.attachShader(shaderProgram, fragmentShader);
  //link the shader program
  gl.linkProgram(shaderProgram);

  // check for compilation and linking status
  if (!gl.getProgramParameter(shaderProgram, gl.LINK_STATUS)) {
    console.log(gl.getShaderInfoLog(vertexShader));
    console.log(gl.getShaderInfoLog(fragmentShader));
  }

  //finally use the program.
  gl.useProgram(shaderProgram);

  return shaderProgram;
}

function initGL(canvas) {
  try {
    gl = canvas.getContext("webgl2"); // the graphics webgl2 context
    gl.viewportWidth = canvas.width; // the width of the canvas
    gl.viewportHeight = canvas.height; // the height
  } catch (e) {}
  if (!gl) {
    alert("WebGL initialization failed");
  }
}
function changeClickedButton(drawdiffOutput1){
  clickedButton = 1;
  drawdiffOutput = drawdiffOutput1;
  console.log(drawdiffOutput);
  drawScene();
}

function initSquareBuffer() {
  // buffer for point locations
  const sqVertices = new Float32Array([
    0.5, 0.5, -0.5, 0.5, -0.5, -0.5, 0.5, -0.5,
  ]);
  sqVertexPositionBuffer = gl.createBuffer();
  gl.bindBuffer(gl.ARRAY_BUFFER, sqVertexPositionBuffer);
  gl.bufferData(gl.ARRAY_BUFFER, sqVertices, gl.STATIC_DRAW);
  sqVertexPositionBuffer.itemSize = 2;
  sqVertexPositionBuffer.numItems = 4;

  // buffer for point indices
  const sqIndices = new Uint16Array([0, 1, 2, 0, 2, 3]);
  sqVertexIndexBuffer = gl.createBuffer();
  gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, sqVertexIndexBuffer);
  gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, sqIndices, gl.STATIC_DRAW);
  sqVertexIndexBuffer.itemsize = 1;
  sqVertexIndexBuffer.numItems = 6;
}

function drawSquare(color, mMatrix) {
  gl.uniformMatrix4fv(uMMatrixLocation, false, mMatrix);

  // buffer for point locations
  gl.bindBuffer(gl.ARRAY_BUFFER, sqVertexPositionBuffer);
  gl.vertexAttribPointer(
    aPositionLocation,
    sqVertexPositionBuffer.itemSize,
    gl.FLOAT,
    false,
    0,
    0
  );

  // buffer for point indices
  gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, sqVertexIndexBuffer);

  gl.uniform4fv(uColorLoc, color);

  // now draw the square
  if(clickedButton == 0){
  gl.drawElements(
    gl.TRIANGLES,
    sqVertexIndexBuffer.numItems,
    gl.UNSIGNED_SHORT,
    0
  );
  }
  else{
    gl.drawElements(
      drawdiffOutput,
      sqVertexIndexBuffer.numItems,
      gl.UNSIGNED_SHORT,
      0
    );
  }
}
function initCircle(){
  var vertices1 = [];
  for (var i=0.0; i<=360; i+=1){
    var tmp = [
      0.5*Math.sin(degToRad(i)),
      0.5*Math.cos(degToRad(i)),
    ];
    tmp = tmp.concat([0.0,0.0]);
    vertices1 = vertices1.concat(tmp);
    // console.log(vertices)
  }
  console.log(vertices1);
  circleBuf = gl.createBuffer();
  gl.bindBuffer(gl.ARRAY_BUFFER, circleBuf);
  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(vertices1),gl.STATIC_DRAW);
  circleBuf.itemSize = 2;
  circleBuf.numItems = 722;

  //buffer for point indices
  var circleIndex = [];
  for(var i=0;i<=718;i+=1){
    circleIndex = circleIndex.concat(i);
    circleIndex = circleIndex.concat(i+1);
    circleIndex = circleIndex.concat(i+2);
  }
  console.log(circleIndex);
  circleIndexBuf = gl.createBuffer();
  gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER,circleIndexBuf);
  gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, new Uint16Array(circleIndex), gl.STATIC_DRAW);
  circleIndexBuf.itemsize = 1;
  circleIndexBuf.numItems = 2157;

}

function drawCircle(color, mMatrix){
  gl.uniformMatrix4fv(uMMatrixLocation, false, mMatrix);

  // buffer for point locations
  gl.bindBuffer(gl.ARRAY_BUFFER, circleBuf);
  gl.vertexAttribPointer(
    aPositionLocation,
    circleBuf.itemSize,
    gl.FLOAT,
    false,
    0,
    0
  );

  // buffer for point indices
  gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, circleIndexBuf);

  gl.uniform4fv(uColorLoc, color);

  // now draw the square
  if(clickedButton == 0){
  gl.drawElements(
    gl.TRIANGLES,
    circleIndexBuf.numItems,
    gl.UNSIGNED_SHORT,
    0
  );
  }
  else{
    gl.drawElements(
      drawdiffOutput,
      circleIndexBuf.numItems,
      gl.UNSIGNED_SHORT,
      0
    );
  }
}

function initTriangleBuffer() {
  // buffer for point locations
  const triangleVertices = new Float32Array([0.0, 0.5, -0.5, -0.5, 0.5, -0.5]);
  triangleBuf = gl.createBuffer();
  gl.bindBuffer(gl.ARRAY_BUFFER, triangleBuf);
  gl.bufferData(gl.ARRAY_BUFFER, triangleVertices, gl.STATIC_DRAW);
  triangleBuf.itemSize = 2;
  triangleBuf.numItems = 3;

  // buffer for point indices
  const triangleIndices = new Uint16Array([0, 1, 2]);
  triangleIndexBuf = gl.createBuffer();
  gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, triangleIndexBuf);
  gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, triangleIndices, gl.STATIC_DRAW);
  triangleIndexBuf.itemsize = 1;
  triangleIndexBuf.numItems = 3;
}

function drawTriangle(color, mMatrix) {
  gl.uniformMatrix4fv(uMMatrixLocation, false, mMatrix);

  // buffer for point locations
  gl.bindBuffer(gl.ARRAY_BUFFER, triangleBuf);
  gl.vertexAttribPointer(
    aPositionLocation,
    triangleBuf.itemSize,
    gl.FLOAT,
    false,
    0,
    0
  );

  // buffer for point indices
  gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, triangleIndexBuf);

  gl.uniform4fv(uColorLoc, color);

  // now draw the square
  if(clickedButton == 0){
    gl.drawElements(
      gl.TRIANGLES,
      triangleIndexBuf.numItems,
      gl.UNSIGNED_SHORT,
      0
    );
    }
    else{
      gl.drawElements(
        drawdiffOutput,
        triangleIndexBuf.numItems,
        gl.UNSIGNED_SHORT,
        0
      );
    }
}


function drawScene(){
    
    gl.viewport(0, 0, gl.viewportWidth, gl.viewportHeight);
    
    if (animation) {
      window.cancelAnimationFrame(animation);
    }
    var animate = function (){
      gl.clearColor(1, 1, 1, 1.0);
      gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
      mat4.identity(mMatrix);
      //---------------------------SKY----------------------------------------------------
      pushMatrix(matrixStack,mMatrix);
      mMatrix = mat4.scale(mMatrix,[4.0,4.7,1.0]);

      color = [0,1.0,0.92,1.0];
      drawSquare(color,mMatrix);
      mMatrix = popMatrix(matrixStack);

      //-----------------------green lawn beneath house--------------------------------------------------------
      pushMatrix(matrixStack, mMatrix);
      mMatrix = mat4.scale(mMatrix,[2.0,0.8,1.0]);
      mMatrix = mat4.translate(mMatrix,[0.0,-0.95,0.0]);
      color = [0.0,1.0,0.0,1.0];
      drawSquare(color,mMatrix);

      mMatrix=popMatrix(matrixStack);

    //--------------------path triangle-------------------------------------------------------
      pushMatrix(matrixStack, mMatrix);
      mMatrix = mat4.rotate(mMatrix,degToRad(36),[0,0,1]);
      mMatrix = mat4.scale(mMatrix,[2.09,1.60,1.0]);
      mMatrix = mat4.translate(mMatrix,[-0.110,-0.55,0.0]);
      color = [0.498, 0.631, 0.035,1.0];
      drawTriangle(color,mMatrix);

      mMatrix = popMatrix(matrixStack);
    //----------------------------------Mountain work---------------------------------------------
    //-------------------------behind tree mountain-----------------------------------------------------

    pushMatrix(matrixStack, mMatrix);
    mMatrix = mat4.scale(mMatrix, [0.6, 0.15, 1.0]);
    mMatrix = mat4.translate(mMatrix,[1.35, 0.22, 0.0]);
    color = [0.71, 0.318, 0, 1];
    drawTriangle(color, mMatrix);
    mMatrix = popMatrix(matrixStack);

    //------------------------left mountain ---------------------------------------------------------------

    pushMatrix(matrixStack, mMatrix);
    mMatrix = mat4.scale(mMatrix,[0.9,0.46,1.0]);
    mMatrix = mat4.translate(mMatrix,[-0.5,0.0,0.0]);


    pushMatrix(matrixStack, mMatrix);
    mMatrix = mat4.rotate(mMatrix, degToRad(-6), [0, 0, 1]);
    mMatrix = mat4.scale(mMatrix, [1.20, 0.35, 1.0]);
    mMatrix = mat4.rotate(mMatrix, degToRad(17), [0, 0, 1]);
    mMatrix = mat4.translate(mMatrix,[-0.07, 0.23, 0.0]);
    color = [0.71, 0.318, 0, 1];
    drawTriangle(color, mMatrix);
    mMatrix = popMatrix(matrixStack);

    pushMatrix(matrixStack,mMatrix);
    mMatrix = mat4.scale(mMatrix,[0.25,0.9,1.0]);
    mMatrix = mat4.translate(mMatrix,[-1.9,0.2,0.0]);
    mMatrix = mat4.rotate(mMatrix,degToRad(-73),[0,0,1]);
    mMatrix = mat4.scale(mMatrix,[0.47,2.1,1.0]);
    mMatrix = mat4.translate(mMatrix,[0.20,-0.18,0.0]);
    color =  [0.459, 0.212, 0.008,1.0];
    drawTriangle(color,mMatrix);
    mMatrix = popMatrix(matrixStack);
    mMatrix = popMatrix(matrixStack);

    //------------------------------middle mountain-------------------------------------------------------------
    pushMatrix(matrixStack, mMatrix);
    mMatrix = mat4.scale(mMatrix,[0.9,0.75,1.0]);
    mMatrix = mat4.translate(mMatrix,[0.2,0.0,0.0]);


    pushMatrix(matrixStack, mMatrix);
    mMatrix = mat4.rotate(mMatrix, degToRad(-6), [0, 0, 1]);
    mMatrix = mat4.scale(mMatrix, [1.20, 0.35, 1.0]);
    mMatrix = mat4.rotate(mMatrix, degToRad(17), [0, 0, 1]);
    mMatrix = mat4.translate(mMatrix,[0.0, 0.31, 0.0]);
    color = [0.71, 0.318, 0, 1];
    drawTriangle(color, mMatrix);
    mMatrix = popMatrix(matrixStack);

    pushMatrix(matrixStack,mMatrix);
    mMatrix = mat4.scale(mMatrix,[0.25,0.9,1.0]);
    mMatrix = mat4.translate(mMatrix,[-1.9,0.2,0.0]);
    mMatrix = mat4.rotate(mMatrix,degToRad(-73),[0,0,1]);
    mMatrix = mat4.scale(mMatrix,[0.47,2.1,1.0]);
    mMatrix = mat4.translate(mMatrix,[0.29,-0.07,0.0]);
    color =  [0.459, 0.212, 0.008,1.0];
    drawTriangle(color,mMatrix);
    mMatrix = popMatrix(matrixStack);
    mMatrix = popMatrix(matrixStack);
    //--------------------------------------------------------------------------------------------
    

    //--------------------------------River Work-------------------------------------------------
    pushMatrix(matrixStack,mMatrix);
    mMatrix = mat4.scale(mMatrix,[5.0,0.3,1.0]);
    mMatrix = mat4.translate(mMatrix,[0.0, -0.75, 0.0]);
    color = [0.0,0.0,0.8,1.0]
    drawSquare(color, mMatrix);
    mMatrix = popMatrix(matrixStack);

    //white line in river left
    pushMatrix(matrixStack,mMatrix);
    mMatrix = mat4.translate(mMatrix,[-0.5,-0.27,0.0]);
    mMatrix = mat4.scale(mMatrix,[0.4,0.005,1.0]);
    color = [0.98, 0.98, 0.945,1.0];
    drawSquare(color,mMatrix);
    mMatrix = popMatrix(matrixStack);
      // right
    pushMatrix(matrixStack,mMatrix);
    mMatrix = mat4.translate(mMatrix,[0.7,-0.31,0.0]);
    mMatrix = mat4.scale(mMatrix,[0.4,0.005,1.0]);
    color = [0.98, 0.98, 0.945,1.0];
    drawSquare(color,mMatrix);
    mMatrix = popMatrix(matrixStack);
      //middle
    pushMatrix(matrixStack,mMatrix);
    mMatrix = mat4.translate(mMatrix,[0.07,-0.15,0.0]);
    mMatrix = mat4.scale(mMatrix,[0.4,0.005,1.0]);
    color = [0.98, 0.98, 0.945,1.0];
    drawSquare(color,mMatrix);
    mMatrix = popMatrix(matrixStack);

    //-------------------------------Between River and Mountain gree patch------------------------------------------
    pushMatrix(matrixStack,mMatrix);
    mMatrix = mat4.scale(mMatrix,[5.0,0.05,1.0]);
    mMatrix = mat4.translate(mMatrix,[0.0, -1.35, 0.0]);
    color = [0.0,1.0,0.0,1.0]
    drawSquare(color, mMatrix);
    mMatrix = popMatrix(matrixStack);
    //------------------------------------------------------------------------------------------------
    


    //-------------------------------Bird work-------------------------------------------------------
    //--------first bird-------------------------------------
    pushMatrix(matrixStack,mMatrix);
    mMatrix = mat4.translate(mMatrix,[-0.03,0.72,0.0]);
    mMatrix = mat4.scale(mMatrix,[0.02,0.020,1.0]);
    color = [0.0, 0.0, 0.0, 1.0];
    //left feather
    pushMatrix(matrixStack,mMatrix);
    mMatrix = mat4.translate(mMatrix,[-0.6,0.0,0.0]);
    mMatrix = mat4.rotate(mMatrix, degToRad(-8),[0,0,1]);
    mMatrix = mat4.scale(mMatrix,[4.5,0.7,1.0]);
    // color = [0.0, 0.0, 0.0, 1.0];
    drawTriangle(color,mMatrix);
    mMatrix = popMatrix(matrixStack);

    //body
    pushMatrix(matrixStack,mMatrix);
    mMatrix = mat4.translate(mMatrix,[1.7,-1.1,0.0]);
    mMatrix = mat4.scale(mMatrix,[1.15,1.15,1.0]);
    // color = [1.0, 0.0, 0.0, 1.0];
    drawSquare(color,mMatrix);
    mMatrix = popMatrix(matrixStack);

    //right feather
    pushMatrix(matrixStack,mMatrix);
    mMatrix = mat4.translate(mMatrix,[4.1,0.0,0.0]);
    mMatrix = mat4.rotate(mMatrix, degToRad(8),[0,0,1]);
    mMatrix = mat4.scale(mMatrix,[4.5,0.6,1.0]);
    // color = [1.0, 0.0, 0.0, 1.0];
    drawTriangle(color,mMatrix);
    mMatrix = popMatrix(matrixStack);

    mMatrix = popMatrix(matrixStack);

    //----------------second bird--------------------------------------------
    pushMatrix(matrixStack,mMatrix);
    mMatrix = mat4.translate(mMatrix,[-0.24,0.80,0.0]);
    mMatrix = mat4.scale(mMatrix,[0.016,0.016,1.0]);

    //left feather
    pushMatrix(matrixStack,mMatrix);
    mMatrix = mat4.translate(mMatrix,[-0.6,0.0,0.0]);
    mMatrix = mat4.rotate(mMatrix, degToRad(-8),[0,0,1]);
    mMatrix = mat4.scale(mMatrix,[4.5,0.7,1.0]);
    // color = [1.0, 0.0, 0.0, 1.0];
    drawTriangle(color,mMatrix);
    mMatrix = popMatrix(matrixStack);

    //body
    pushMatrix(matrixStack,mMatrix);
    mMatrix = mat4.translate(mMatrix,[1.7,-1.1,0.0]);
    mMatrix = mat4.scale(mMatrix,[1.15,1.15,1.0]);
    // color = [1.0, 0.0, 0.0, 1.0];
    drawSquare(color,mMatrix);
    mMatrix = popMatrix(matrixStack);

    //right feather
    pushMatrix(matrixStack,mMatrix);
    mMatrix = mat4.translate(mMatrix,[4.1,0.0,0.0]);
    mMatrix = mat4.rotate(mMatrix, degToRad(8),[0,0,1]);
    mMatrix = mat4.scale(mMatrix,[4.5,0.6,1.0]);
    // color = [1.0, 0.0, 0.0, 1.0];
    drawTriangle(color,mMatrix);
    mMatrix = popMatrix(matrixStack);

    mMatrix = popMatrix(matrixStack);

    //next bird
    pushMatrix(matrixStack,mMatrix);
    mMatrix = mat4.translate(mMatrix,[0.34,0.850,0.0]);
    mMatrix = mat4.scale(mMatrix,[0.013,0.013,1.0]);

    //left feather
    pushMatrix(matrixStack,mMatrix);
    mMatrix = mat4.translate(mMatrix,[-0.6,0.0,0.0]);
    mMatrix = mat4.rotate(mMatrix, degToRad(-8),[0,0,1]);
    mMatrix = mat4.scale(mMatrix,[4.5,0.7,1.0]);
    // color = [1.0, 0.0, 0.0, 1.0];
    drawTriangle(color,mMatrix);
    mMatrix = popMatrix(matrixStack);

    //body
    pushMatrix(matrixStack,mMatrix);
    mMatrix = mat4.translate(mMatrix,[1.7,-1.1,0.0]);
    mMatrix = mat4.scale(mMatrix,[1.15,1.15,1.0]);
    // color = [1.0, 0.0, 0.0, 1.0];
    drawSquare(color,mMatrix);
    mMatrix = popMatrix(matrixStack);

    //right feather
    pushMatrix(matrixStack,mMatrix);
    mMatrix = mat4.translate(mMatrix,[4.1,0.0,0.0]);
    mMatrix = mat4.rotate(mMatrix, degToRad(8),[0,0,1]);
    mMatrix = mat4.scale(mMatrix,[4.5,0.6,1.0]);
    // color = [1.0, 0.0, 0.0, 1.0];
    drawTriangle(color,mMatrix);
    mMatrix = popMatrix(matrixStack);

    mMatrix = popMatrix(matrixStack);

    //new bird
    pushMatrix(matrixStack,mMatrix);
    mMatrix = mat4.translate(mMatrix,[-0.074,0.840,0.0]);
    mMatrix = mat4.scale(mMatrix,[0.01,0.01,1.0]);

    //left feather
    pushMatrix(matrixStack,mMatrix);
    mMatrix = mat4.translate(mMatrix,[-0.6,0.0,0.0]);
    mMatrix = mat4.rotate(mMatrix, degToRad(-8),[0,0,1]);
    mMatrix = mat4.scale(mMatrix,[4.5,0.7,1.0]);
    // color = [1.0, 0.0, 0.0, 1.0];
    drawTriangle(color,mMatrix);
    mMatrix = popMatrix(matrixStack);

    //body
    pushMatrix(matrixStack,mMatrix);
    mMatrix = mat4.translate(mMatrix,[1.7,-1.1,0.0]);
    mMatrix = mat4.scale(mMatrix,[1.15,1.15,1.0]);
    // color = [1.0, 0.0, 0.0, 1.0];
    drawSquare(color,mMatrix);
    mMatrix = popMatrix(matrixStack);

    //right feather
    pushMatrix(matrixStack,mMatrix);
    mMatrix = mat4.translate(mMatrix,[4.1,0.0,0.0]);
    mMatrix = mat4.rotate(mMatrix, degToRad(8),[0,0,1]);
    mMatrix = mat4.scale(mMatrix,[4.5,0.6,1.0]);
    // color = [1.0, 0.0, 0.0, 1.0];
    drawTriangle(color,mMatrix);
    mMatrix = popMatrix(matrixStack);

    mMatrix = popMatrix(matrixStack);

    //last bird------------------
    pushMatrix(matrixStack,mMatrix);
    mMatrix = mat4.translate(mMatrix,[0.124,0.870,0.0]);
    mMatrix = mat4.scale(mMatrix,[0.007,0.007,1.0]);

    //left feather
    pushMatrix(matrixStack,mMatrix);
    mMatrix = mat4.translate(mMatrix,[-0.6,0.0,0.0]);
    mMatrix = mat4.rotate(mMatrix, degToRad(-8),[0,0,1]);
    mMatrix = mat4.scale(mMatrix,[4.5,0.7,1.0]);
    // color = [1.0, 0.0, 0.0, 1.0];
    drawTriangle(color,mMatrix);
    mMatrix = popMatrix(matrixStack);

    //body
    pushMatrix(matrixStack,mMatrix);
    mMatrix = mat4.translate(mMatrix,[1.7,-1.1,0.0]);
    mMatrix = mat4.scale(mMatrix,[1.15,1.15,1.0]);
    // color = [1.0, 0.0, 0.0, 1.0];
    drawSquare(color,mMatrix);
    mMatrix = popMatrix(matrixStack);

    //right feather
    pushMatrix(matrixStack,mMatrix);
    mMatrix = mat4.translate(mMatrix,[4.1,0.0,0.0]);
    mMatrix = mat4.rotate(mMatrix, degToRad(8),[0,0,1]);
    mMatrix = mat4.scale(mMatrix,[4.5,0.6,1.0]);
    // color = [1.0, 0.0, 0.0, 1.0];
    drawTriangle(color,mMatrix);
    mMatrix = popMatrix(matrixStack);

    mMatrix = popMatrix(matrixStack);

    //------------------------------------Tree-------------------------------------------------------
        
    pushMatrix(matrixStack, mMatrix);

    //--------------stem------------------------------------------------------
    mMatrix = mat4.translate(mMatrix,[0.49, 0.0, 0.0]);

    pushMatrix(matrixStack,mMatrix);
    mMatrix = mat4.scale(mMatrix,[0.04,0.3,1.0]);
    mMatrix = mat4.translate(mMatrix,[7.95,0.3,0.0]);
    color = [0.29, 0.176, 0.004, 1.0]
    drawSquare(color,mMatrix);
    mMatrix = popMatrix(matrixStack);

    //------------------------- small tree triangle--------------------------------------------------
    mMatrix = mat4.scale(mMatrix,[1.1,1.1,1.0]);
    pushMatrix(matrixStack, mMatrix);
    mMatrix = mat4.scale(mMatrix,[0.3,0.3,1.0]);
    mMatrix = mat4.translate(mMatrix,[1.0,1.1,0.0]);
    color = [0.173, 0.478, 0.086,1.0];
    drawTriangle(color,mMatrix);
    mMatrix = popMatrix(matrixStack);

    pushMatrix(matrixStack, mMatrix);
    mMatrix = mat4.scale(mMatrix,[0.3,0.3,1.0]);
    mMatrix = mat4.translate(mMatrix,[1.0,1.31,0.0]);
    color = [0.208, 0.631, 0.09,1.0];
    drawTriangle(color,mMatrix);
    mMatrix = popMatrix(matrixStack);

    pushMatrix(matrixStack, mMatrix);
    mMatrix = mat4.scale(mMatrix,[0.3,0.3,1.0]);
    mMatrix = mat4.translate(mMatrix,[1.0,1.5,0.0]);
    color = [0.278, 0.871, 0.118,1.0];
    drawTriangle(color,mMatrix);
    mMatrix = popMatrix(matrixStack);

    mMatrix = popMatrix(matrixStack);
    //---------------------------------------------------------------------------

    //-------------------------------middle largest tree--------------------------------------
    pushMatrix(matrixStack, mMatrix);
    mMatrix = mat4.translate(mMatrix,[0.09,0.059,0.0]);
    mMatrix = mat4.scale(mMatrix,[1.5,1.3,0.0]);

    //--------------stem------------------------------------------------------
    pushMatrix(matrixStack,mMatrix);
    mMatrix = mat4.scale(mMatrix,[0.04,0.42,1.0]);
    mMatrix = mat4.translate(mMatrix,[7.6,0.3,0.0]);
    color = [0.29, 0.176, 0.004, 1.0]
    drawSquare(color,mMatrix);
    mMatrix = popMatrix(matrixStack);

    //-------------------------big tree triangle--------------------------------------------------
    pushMatrix(matrixStack, mMatrix);
    mMatrix = mat4.scale(mMatrix,[0.3,0.3,1.0]);
    mMatrix = mat4.translate(mMatrix,[1.0,0.9,0.0]);
    color = [0.173, 0.478, 0.086,1.0];
    drawTriangle(color,mMatrix);
    mMatrix = popMatrix(matrixStack);

    pushMatrix(matrixStack, mMatrix);
    mMatrix = mat4.scale(mMatrix,[0.3,0.3,1.0]);
    mMatrix = mat4.translate(mMatrix,[1.0,1.1,0.0]);
    color = [0.208, 0.631, 0.09,1.0];
    drawTriangle(color,mMatrix);
    mMatrix = popMatrix(matrixStack);

    pushMatrix(matrixStack, mMatrix);
    mMatrix = mat4.scale(mMatrix,[0.3,0.3,1.0]);
    mMatrix = mat4.translate(mMatrix,[1.0,1.3,0.0]);
    color = [0.278, 0.871, 0.118,1.0];
    drawTriangle(color,mMatrix);
    mMatrix = popMatrix(matrixStack);

    mMatrix = popMatrix(matrixStack);
    //---------------------------------------------------------------------------
    

    //--------------stem------------------------------------------------------
    pushMatrix(matrixStack,mMatrix);
    mMatrix = mat4.scale(mMatrix,[0.04,0.3,1.0]);
    mMatrix = mat4.translate(mMatrix,[7.6,0.3,0.0]);
    color = [0.29, 0.176, 0.004, 1.0]
    drawSquare(color,mMatrix);
    mMatrix = popMatrix(matrixStack);

    //-------------------------least small tree triangle--------------------------------------------------
    pushMatrix(matrixStack, mMatrix);
    mMatrix = mat4.scale(mMatrix,[0.3,0.3,1.0]);
    mMatrix = mat4.translate(mMatrix,[1.0,0.9,0.0]);
    color = [0.173, 0.478, 0.086,1.0];
    drawTriangle(color,mMatrix);
    mMatrix = popMatrix(matrixStack);

    pushMatrix(matrixStack, mMatrix);
    mMatrix = mat4.scale(mMatrix,[0.3,0.3,1.0]);
    mMatrix = mat4.translate(mMatrix,[1.0,1.1,0.0]);
    color = [0.208, 0.631, 0.09,1.0];
    drawTriangle(color,mMatrix);
    mMatrix = popMatrix(matrixStack);

    pushMatrix(matrixStack, mMatrix);
    mMatrix = mat4.scale(mMatrix,[0.3,0.3,1.0]);
    mMatrix = mat4.translate(mMatrix,[1.0,1.3,0.0]);
    color = [0.278, 0.871, 0.118,1.0];
    drawTriangle(color,mMatrix);
    mMatrix = popMatrix(matrixStack);
    //---------------------------------------------------------------------------

    //------------------------------------Boat------------------------------------------------
    pushMatrix(matrixStack,mMatrix);
    x_boat += addValue;
    if(x_boat >= 0.7){
      addValue = -1*addValue;
      
    }
    if(x_boat <= -0.7){
      addValue = -1*addValue;
    }

    mMatrix = mat4.translate(mMatrix,[x_boat,0.0,0.0]);
    pushMatrix(matrixStack,mMatrix);


    //flag pole
    mMatrix = mat4.scale(mMatrix,[0.016,0.3,1.0]);
    color = [0.0,0.0,0.0,1.0];
    drawSquare(color,mMatrix);
    mMatrix = popMatrix(matrixStack);
    
    pushMatrix(matrixStack,mMatrix);
    //rope of flag pole
    mMatrix = mat4.rotate(mMatrix,degToRad(-38),[0,0,1]);
    mMatrix = mat4.scale(mMatrix,[0.01,0.33,1.0]);
    mMatrix = mat4.translate(mMatrix,[-5.5,-0.30,0.0]);
    color = [0.0,0.0,0.0,1.0];
    drawSquare(color,mMatrix);
    mMatrix = popMatrix(matrixStack);

    pushMatrix(matrixStack,mMatrix);
    //flag
    mMatrix = mat4.rotate(mMatrix,degToRad(-90),[0,0,1]);
    mMatrix = mat4.scale(mMatrix,[0.2,0.2,1.0]);
    mMatrix = mat4.translate(mMatrix,[0.0,0.54,0.0]);
    color = [1.0,0.0,0.0,1.0];
    drawTriangle(color,mMatrix);
    mMatrix = popMatrix(matrixStack);

    //boat deck
    pushMatrix(matrixStack,mMatrix);
    mMatrix = mat4.scale(mMatrix,[0.34,0.08,1.0]);
    mMatrix = mat4.translate(mMatrix,[-0.03,-2.3,0.0]);
    color = [0.871, 0.871, 0.796,1.0];
    drawSquare(color,mMatrix);

    mMatrix = popMatrix(matrixStack);
    //triangle
    pushMatrix(matrixStack,mMatrix);
    mMatrix = mat4.scale(mMatrix,[0.086,0.086,1.0]);
    mMatrix = mat4.translate(mMatrix,[-2.17,-2.05,0.0]);
    mMatrix = mat4.rotate(mMatrix,degToRad(-63),[0,0,1]);
    mMatrix = mat4.translate(mMatrix,[0.0,0.3,0.0]);
    color = [0.871, 0.871, 0.796,1.0];
    drawTriangle(color,mMatrix);
    mMatrix = popMatrix(matrixStack);

    pushMatrix(matrixStack,mMatrix);
    mMatrix = mat4.scale(mMatrix,[0.086,0.086,1.0]);
    mMatrix = mat4.translate(mMatrix,[1.82,-2.05,0.0]);
    mMatrix = mat4.rotate(mMatrix,degToRad(-63),[0,0,1]);
    mMatrix = mat4.translate(mMatrix,[0.0,0.3,0.0]);
    color = [0.871, 0.871, 0.796,1.0];
    drawTriangle(color,mMatrix);
    mMatrix = popMatrix(matrixStack);

    mMatrix = popMatrix(matrixStack);
    //-------------------------SUN---------------------------------------------------------------------------------

      pushMatrix(matrixStack,mMatrix);
      
      mMatrix = mat4.translate(mMatrix,[-0.76,0.8,0.0]);
      pushMatrix(matrixStack,mMatrix);

      mMatrix = mat4.scale(mMatrix,[0.25,0.25,1.0]);
      color = [1, 0.984, 0,1.0];
      drawCircle(color,mMatrix);
      mMatrix = popMatrix(matrixStack);

      //-----------------sunray----------------------------------------------------------------------------

      degreeSun -= 0.3;
      
      pushMatrix(matrixStack,mMatrix);
      mMatrix = mat4.rotate(mMatrix,degToRad(degreeSun),[0,0,1]);
      mMatrix = mat4.scale(mMatrix,[0.4,0.01,1.0]);
      color = [1, 0.984, 0,1.0];
      drawSquare(color,mMatrix);
      mMatrix = popMatrix(matrixStack);

      pushMatrix(matrixStack,mMatrix);
      mMatrix = mat4.rotate(mMatrix,degToRad(degreeSun),[0,0,1]);
      mMatrix = mat4.scale(mMatrix,[0.01,0.4,1.0]);
      color = [1, 0.984, 0,1.0];
      drawSquare(color,mMatrix);
      mMatrix = popMatrix(matrixStack);

      pushMatrix(matrixStack,mMatrix);
      mMatrix = mat4.rotate(mMatrix,degToRad(45 + degreeSun),[0,0,1]);
      mMatrix = mat4.scale(mMatrix,[0.01,0.4,1.0]);
      color = [1, 0.984, 0,1.0];
      drawSquare(color,mMatrix);
      mMatrix = popMatrix(matrixStack);

      pushMatrix(matrixStack,mMatrix);
      mMatrix = mat4.rotate(mMatrix,degToRad(-45 + degreeSun),[0,0,1]);
      mMatrix = mat4.scale(mMatrix,[0.01,0.4,1.0]);
      color = [1, 0.984, 0,1.0];
      drawSquare(color,mMatrix);
      mMatrix = popMatrix(matrixStack);
      
      mMatrix = popMatrix(matrixStack);
      
      //----------------------------------------------------------------------------------------------------

      //----------------------------------------------------FAN------------------------------
      //-----------right fan-----------------------------
      pushMatrix(matrixStack,mMatrix);
      mMatrix = mat4.translate(mMatrix,[0.7,-0.15,0.0]);
      pushMatrix(matrixStack,mMatrix);
      //stick------------
      mMatrix = mat4.scale(mMatrix,[0.03,0.5,1.0]);
      mMatrix = mat4.translate(mMatrix,[0.0,-0.50,1.0]);
      color = [0.114, 0.169, 0.114,1.0];
      drawSquare(color,mMatrix);

      mMatrix = popMatrix(matrixStack);

      degree2 -= 0.5;

      
      //fan wings-------------------------------

      //working roation on fan------------
      pushMatrix(matrixStack, mMatrix);
      pushMatrix(matrixStack,mMatrix);
      mMatrix = mat4.translate(mMatrix,[0.0,-0.5,0.0]);
      mMatrix = mat4.translate(mMatrix,[0.0,0.5,0.0]);
      
      mMatrix = mat4.rotate(mMatrix,degToRad(degree2),[0,0,1]);
      mMatrix = mat4.scale(mMatrix,[0.1,0.22,1.0]);
      mMatrix = mat4.translate(mMatrix,[0.0,-0.5,0.0]);
      
      color = [0.494, 0.612, 0,1.0];
      drawTriangle(color,mMatrix);
      mMatrix = popMatrix(matrixStack);

      pushMatrix(matrixStack,mMatrix);
      mMatrix = mat4.translate(mMatrix,[0.0,-0.5,0.0]);
      mMatrix = mat4.translate(mMatrix,[0.0,0.5,0.0]);
      
      mMatrix = mat4.rotate(mMatrix,degToRad(degree2+180),[0,0,1]);
      mMatrix = mat4.scale(mMatrix,[0.1,0.22,1.0]);
      mMatrix = mat4.translate(mMatrix,[0.0,-0.5,0.0]);
      
      color = [0.494, 0.612, 0,1.0];
      drawTriangle(color,mMatrix);
      mMatrix = popMatrix(matrixStack);

      mMatrix = popMatrix(matrixStack);

      pushMatrix(matrixStack, mMatrix);
      pushMatrix(matrixStack,mMatrix);
      mMatrix = mat4.translate(mMatrix,[0.0,-0.5,0.0]);
      mMatrix = mat4.translate(mMatrix,[0.0,0.5,0.0]);
      
      mMatrix = mat4.rotate(mMatrix,degToRad(degree2 + 90),[0,0,1]);
      mMatrix = mat4.scale(mMatrix,[0.1,0.22,1.0]);
      mMatrix = mat4.translate(mMatrix,[0.0,-0.5,0.0]);
      // mMatrix = mat4.scale(mMatrix,[0.22,0.1,1.0]);
      color = [0.494, 0.612, 0,1.0];
      drawTriangle(color,mMatrix);
      mMatrix = popMatrix(matrixStack);

      pushMatrix(matrixStack,mMatrix);
      mMatrix = mat4.translate(mMatrix,[0.0,-0.5,0.0]);
      mMatrix = mat4.translate(mMatrix,[0.0,0.5,0.0]);
      
      mMatrix = mat4.rotate(mMatrix,degToRad(degree2 - 90),[0,0,1]);
      mMatrix = mat4.scale(mMatrix,[0.1,0.22,1.0]);
      mMatrix = mat4.translate(mMatrix,[0.0,-0.5,0.0]);
      
      color = [0.494, 0.612, 0,1.0];
      drawTriangle(color,mMatrix);
      mMatrix = popMatrix(matrixStack);

      mMatrix = popMatrix(matrixStack);

      // center black thing
      pushMatrix(matrixStack, mMatrix);
      mMatrix = mat4.scale(mMatrix,[0.08,0.08,1.0]);
      color = [0.039, 0.039, 0.039, 1.0];
      drawCircle(color,mMatrix);
      mMatrix = popMatrix(matrixStack);

      mMatrix = popMatrix(matrixStack);


      //-----------left fan------------------------------------------------------------
      pushMatrix(matrixStack,mMatrix);
      mMatrix = mat4.translate(mMatrix,[-0.7,0.03,0.0]);
      pushMatrix(matrixStack,mMatrix);
      //stick------------
      mMatrix = mat4.scale(mMatrix,[0.03,0.5,1.0]);
      mMatrix = mat4.translate(mMatrix,[0.0,-0.50,1.0]);
      color = [0.114, 0.169, 0.114,1.0];
      drawSquare(color,mMatrix);

      mMatrix = popMatrix(matrixStack);

      //fan wings-------------------------------

      //working roation on fan------------
      pushMatrix(matrixStack, mMatrix);
      pushMatrix(matrixStack,mMatrix);
      mMatrix = mat4.translate(mMatrix,[0.0,-0.5,0.0]);
      mMatrix = mat4.translate(mMatrix,[0.0,0.5,0.0]);
      
      mMatrix = mat4.rotate(mMatrix,degToRad(degree2),[0,0,1]);
      mMatrix = mat4.scale(mMatrix,[0.1,0.22,1.0]);
      mMatrix = mat4.translate(mMatrix,[0.0,-0.5,0.0]);
      
      color = [0.494, 0.612, 0,1.0];
      drawTriangle(color,mMatrix);
      mMatrix = popMatrix(matrixStack);

      pushMatrix(matrixStack,mMatrix);
      mMatrix = mat4.translate(mMatrix,[0.0,-0.5,0.0]);
      mMatrix = mat4.translate(mMatrix,[0.0,0.5,0.0]);
      
      mMatrix = mat4.rotate(mMatrix,degToRad(degree2+180),[0,0,1]);
      mMatrix = mat4.scale(mMatrix,[0.1,0.22,1.0]);
      mMatrix = mat4.translate(mMatrix,[0.0,-0.5,0.0]);
      
      color = [0.494, 0.612, 0,1.0];
      drawTriangle(color,mMatrix);
      mMatrix = popMatrix(matrixStack);

      mMatrix = popMatrix(matrixStack);

      pushMatrix(matrixStack, mMatrix);
      pushMatrix(matrixStack,mMatrix);
      mMatrix = mat4.translate(mMatrix,[0.0,-0.5,0.0]);
      mMatrix = mat4.translate(mMatrix,[0.0,0.5,0.0]);
      
      mMatrix = mat4.rotate(mMatrix,degToRad(degree2 + 90),[0,0,1]);
      mMatrix = mat4.scale(mMatrix,[0.1,0.22,1.0]);
      mMatrix = mat4.translate(mMatrix,[0.0,-0.5,0.0]);
      // mMatrix = mat4.scale(mMatrix,[0.22,0.1,1.0]);
      color = [0.494, 0.612, 0,1.0];
      drawTriangle(color,mMatrix);
      mMatrix = popMatrix(matrixStack);

      pushMatrix(matrixStack,mMatrix);
      mMatrix = mat4.translate(mMatrix,[0.0,-0.5,0.0]);
      mMatrix = mat4.translate(mMatrix,[0.0,0.5,0.0]);
      
      mMatrix = mat4.rotate(mMatrix,degToRad(degree2 - 90),[0,0,1]);
      mMatrix = mat4.scale(mMatrix,[0.1,0.22,1.0]);
      mMatrix = mat4.translate(mMatrix,[0.0,-0.5,0.0]);
      // mMatrix = mat4.scale(mMatrix,[0.22,0.1,1.0]);
      
      color = [0.494, 0.612, 0,1.0];
      drawTriangle(color,mMatrix);
      mMatrix = popMatrix(matrixStack);

      mMatrix = popMatrix(matrixStack);

      // center black thing
      pushMatrix(matrixStack, mMatrix);
      mMatrix = mat4.scale(mMatrix,[0.08,0.08,1.0]);
      color = [0.039, 0.039, 0.039, 1.0];
      drawCircle(color,mMatrix);
      mMatrix = popMatrix(matrixStack);

      mMatrix = popMatrix(matrixStack);

      // --------------------------cloud---------------------------------------

      pushMatrix(matrixStack,mMatrix);
      mMatrix = mat4.scale(mMatrix,[0.43,0.23,1.0]);
      mMatrix = mat4.translate(mMatrix,[-2.0,1.97,0.0]);
      color = [1.0,1.0,1.0,1.0];
      drawCircle(color,mMatrix);
      mMatrix = popMatrix(matrixStack);
      
      pushMatrix(matrixStack,mMatrix);
      mMatrix = mat4.scale(mMatrix,[0.24,0.16,1.0]);
      mMatrix = mat4.translate(mMatrix,[-2.5,2.71,0.0]);
      color = [1.0,1.0,1.0,1.0];
      drawCircle(color,mMatrix);
      mMatrix = popMatrix(matrixStack);

      pushMatrix(matrixStack,mMatrix);
      mMatrix = mat4.scale(mMatrix,[0.18,0.1,1.0]);
      mMatrix = mat4.rotate(mMatrix,degToRad(1),[0,0,1]);
      mMatrix = mat4.translate(mMatrix,[-2.3,4.50,0.0]);
      color = [1.0,1.0,1.0,1.0];
      drawCircle(color,mMatrix);
      mMatrix = popMatrix(matrixStack);

      //----------------grass--------------------- 
      //house left left
      pushMatrix(matrixStack,mMatrix);
      mMatrix = mat4.scale(mMatrix,[0.13,0.13,1.0]);
      mMatrix = mat4.rotate(mMatrix,degToRad(1),[0,0,1]);
      mMatrix = mat4.translate(mMatrix,[-7.50,-5.0,0.0]);
      color = [0.094, 0.59, 0.039,1.0];
      drawCircle(color,mMatrix);
      mMatrix = popMatrix(matrixStack);

      //house left right
      pushMatrix(matrixStack,mMatrix);
      mMatrix = mat4.scale(mMatrix,[0.18,0.12,1.0]);
      mMatrix = mat4.translate(mMatrix,[-4.9,-5.60,0.0]);
      color = [0.098, 0.471, 0.047,1.0];
      drawCircle(color,mMatrix);
      mMatrix = popMatrix(matrixStack);

      //fan left
      pushMatrix(matrixStack,mMatrix);
      mMatrix = mat4.scale(mMatrix,[0.16,0.14,1.0]);
      mMatrix = mat4.translate(mMatrix,[5.3,-4.40,0.0]);
      color = [0.09, 0.6, 0.03,1.0];
      drawCircle(color,mMatrix);
      mMatrix = popMatrix(matrixStack);

      //fan right
      pushMatrix(matrixStack,mMatrix);
      mMatrix = mat4.scale(mMatrix,[0.3,0.18,1.0]);
      mMatrix = mat4.translate(mMatrix,[3.3,-3.3,0.0]);
      color = [0.059, 0.412, 0.012,1.0];
      drawCircle(color,mMatrix);
      mMatrix = popMatrix(matrixStack);

      //house right right
      pushMatrix(matrixStack,mMatrix);
      mMatrix = mat4.scale(mMatrix,[0.13,0.13,1.0]);
      mMatrix = mat4.translate(mMatrix,[-1.0,-5.0,0.0]);
      color = [0.059, 0.412, 0.012,1.0];
      drawCircle(color,mMatrix);
      mMatrix = popMatrix(matrixStack);


      //house right left
      pushMatrix(matrixStack,mMatrix);
      mMatrix = mat4.scale(mMatrix,[0.13,0.13,1.0]);
      mMatrix = mat4.translate(mMatrix,[-3.00,-5.0,0.0]);
      color = [0.059, 0.412, 0.082,1.0];
      drawCircle(color,mMatrix);
      mMatrix = popMatrix(matrixStack); 

      //house right middle
      pushMatrix(matrixStack,mMatrix);
      mMatrix = mat4.scale(mMatrix,[0.23,0.17,1.0]);
      mMatrix = mat4.translate(mMatrix,[-1.1,-3.8,0.0]);
      color = [0.098, 0.471, 0.047,1.0];
      drawCircle(color,mMatrix);
      mMatrix = popMatrix(matrixStack);

      // front of car grass------------------------------
      //house right right

      pushMatrix(matrixStack,mMatrix);
      mMatrix = mat4.scale(mMatrix,[1.80,1.3,1.0]);
      mMatrix = mat4.translate(mMatrix,[0.1,-0.15,0,0]);
      pushMatrix(matrixStack,mMatrix);
      mMatrix = mat4.scale(mMatrix,[0.13,0.13,1.0]);
      mMatrix = mat4.translate(mMatrix,[-1.0,-5.0,0.0]);
      color = [0.059, 0.412, 0.012,1.0];
      drawCircle(color,mMatrix);
      mMatrix = popMatrix(matrixStack);


      //house right left
      pushMatrix(matrixStack,mMatrix);
      mMatrix = mat4.scale(mMatrix,[0.13,0.13,1.0]);
      mMatrix = mat4.translate(mMatrix,[-3.00,-5.0,0.0]);
      color = [0.059, 0.412, 0.082,1.0];
      drawCircle(color,mMatrix);
      mMatrix = popMatrix(matrixStack); 

      //house right middle
      pushMatrix(matrixStack,mMatrix);
      mMatrix = mat4.scale(mMatrix,[0.23,0.17,1.0]);
      mMatrix = mat4.translate(mMatrix,[-1.1,-3.8,0.0]);
      color = [0.098, 0.471, 0.047,1.0];
      drawCircle(color,mMatrix);
      mMatrix = popMatrix(matrixStack);

      mMatrix = popMatrix(matrixStack);

      //--------------------HOusE-------------------------------------------
      pushMatrix(matrixStack,mMatrix);
      mMatrix = mat4.rotate(mMatrix,degToRad(180),[0,0,1]);
      mMatrix = mat4.scale(mMatrix,[1.4,2.5,1.0]);
      mMatrix = mat4.translate(mMatrix,[0.430,0.31,0.0]);
      color = [1, 0.294, 0,1.0];
      pushMatrix(matrixStack,mMatrix);
      mMatrix = mat4.scale(mMatrix,[0.34,0.08,1.0]);
      mMatrix = mat4.translate(mMatrix,[-0.03,-2.3,0.0]);
      // color = [0.871, 0.871, 0.796,1.0];
      drawSquare(color,mMatrix);

      mMatrix = popMatrix(matrixStack);
      //triangle
      pushMatrix(matrixStack,mMatrix);
      mMatrix = mat4.scale(mMatrix,[0.086,0.086,1.0]);
      mMatrix = mat4.translate(mMatrix,[-2.17,-2.05,0.0]);
      mMatrix = mat4.rotate(mMatrix,degToRad(-63),[0,0,1]);
      mMatrix = mat4.translate(mMatrix,[0.0,0.34,0.0]);
      // color = [0.871, 0.871, 0.796,1.0];
      drawTriangle(color,mMatrix);
      mMatrix = popMatrix(matrixStack);

      pushMatrix(matrixStack,mMatrix);
      mMatrix = mat4.scale(mMatrix,[0.086,0.086,1.0]);
      mMatrix = mat4.translate(mMatrix,[1.82,-2.05,0.0]);
      mMatrix = mat4.rotate(mMatrix,degToRad(-63),[0,0,1]);
      mMatrix = mat4.translate(mMatrix,[0.0,0.3,0.0]);
      // color = [0.871, 0.871, 0.796,1.0];
      drawTriangle(color,mMatrix);
      mMatrix = popMatrix(matrixStack);

      mMatrix = popMatrix(matrixStack);

      //walls
      pushMatrix(matrixStack,mMatrix);
      mMatrix = mat4.scale(mMatrix,[0.470,0.35,1.0]);
      mMatrix = mat4.translate(mMatrix,[-1.3,-1.670,0.0]);
      color = [0.953, 0.969, 0.788,1.0];
      drawSquare(color,mMatrix);

      mMatrix = popMatrix(matrixStack);

      //windows
      color = [0.722, 0.8, 0.024,1.0]
      pushMatrix(matrixStack,mMatrix);
      mMatrix = mat4.scale(mMatrix,[0.11,0.11,1.0]);
      mMatrix = mat4.translate(mMatrix,[-7.0,-4.4,0.0]);
      drawSquare(color,mMatrix);
      mMatrix = popMatrix(matrixStack);

      color = [0.722, 0.8, 0.024,1.0]
      pushMatrix(matrixStack,mMatrix);
      mMatrix = mat4.scale(mMatrix,[0.11,0.11,1.0]);
      mMatrix = mat4.translate(mMatrix,[-4.3,-4.4,0.0]);
      drawSquare(color,mMatrix);
      mMatrix = popMatrix(matrixStack);

      pushMatrix(matrixStack,mMatrix);
      mMatrix = mat4.scale(mMatrix,[0.11,0.21,1.0]);
      mMatrix = mat4.translate(mMatrix,[-5.6,-3.10,0.0]);
      drawSquare(color,mMatrix);
      mMatrix = popMatrix(matrixStack);

      //---------car-------------------------------------------------------
      //top
      pushMatrix(matrixStack,mMatrix);
      mMatrix = mat4.translate(mMatrix,[0.0,-0.07,0.0]);
      pushMatrix(matrixStack,mMatrix);
      mMatrix = mat4.rotate(mMatrix,degToRad(180),[0,0,1]);
      mMatrix = mat4.scale(mMatrix,[0.5,0.6,1.0]);
      mMatrix = mat4.translate(mMatrix,[0.99,1.41,0.0]);
      color = [0.722, 0, 0.102,1.0];
      pushMatrix(matrixStack,mMatrix);
      mMatrix = mat4.scale(mMatrix,[0.34,0.08,1.0]);
      mMatrix = mat4.translate(mMatrix,[-0.03,-2.3,0.0]);
      // color = [0.871, 0.871, 0.796,1.0];
      drawSquare(color,mMatrix);

      mMatrix = popMatrix(matrixStack);
      //triangle
      pushMatrix(matrixStack,mMatrix);
      mMatrix = mat4.scale(mMatrix,[0.086,0.086,1.0]);
      mMatrix = mat4.translate(mMatrix,[-2.17,-2.05,0.0]);
      mMatrix = mat4.rotate(mMatrix,degToRad(-63),[0,0,1]);
      mMatrix = mat4.translate(mMatrix,[0.0,0.34,0.0]);
      // color = [0.871, 0.871, 0.796,1.0];
      drawTriangle(color,mMatrix);
      mMatrix = popMatrix(matrixStack);

      pushMatrix(matrixStack,mMatrix);
      mMatrix = mat4.scale(mMatrix,[0.086,0.086,1.0]);
      mMatrix = mat4.translate(mMatrix,[1.82,-2.05,0.0]);
      mMatrix = mat4.rotate(mMatrix,degToRad(-63),[0,0,1]);
      mMatrix = mat4.translate(mMatrix,[0.0,0.3,0.0]);
      // color = [0.871, 0.871, 0.796,1.0];
      drawTriangle(color,mMatrix);
      mMatrix = popMatrix(matrixStack);

      mMatrix = popMatrix(matrixStack);

      //inner wheels-----------
      pushMatrix(matrixStack,mMatrix);
      mMatrix = mat4.scale(mMatrix,[0.091,0.091,1.0]);
      mMatrix = mat4.translate(mMatrix,[-6.40,-8.99,0.0]);
      color = [0.0,0.0,0.0,1.0];
      drawCircle(color,mMatrix);
      mMatrix = popMatrix(matrixStack);

      pushMatrix(matrixStack,mMatrix);
      mMatrix = mat4.scale(mMatrix,[0.091,0.091,1.0]);
      mMatrix = mat4.translate(mMatrix,[-4.550,-8.90,0.0]);
      color = [0.0,0.0,0.0,1.0];
      drawCircle(color,mMatrix);
      mMatrix = popMatrix(matrixStack);

      //outer wheels---------
      color = [0.498, 0.529, 0.851,1.0]
      pushMatrix(matrixStack,mMatrix);
      mMatrix = mat4.scale(mMatrix,[0.075,0.075,1.0]);
      mMatrix = mat4.translate(mMatrix,[-7.75,-10.90,0.0]);
      // color = [0.0,0.0,0.0,1.0];
      drawCircle(color,mMatrix);
      mMatrix = popMatrix(matrixStack);

      pushMatrix(matrixStack,mMatrix);
      mMatrix = mat4.scale(mMatrix,[0.075,0.075,1.0]);
      mMatrix = mat4.translate(mMatrix,[-5.50,-10.8,0.0]);
      // color = [0.0,0.0,0.0,1.0];
      drawCircle(color,mMatrix);
      mMatrix = popMatrix(matrixStack);

      //bottom
      pushMatrix(matrixStack,mMatrix);
      mMatrix = mat4.rotate(mMatrix,degToRad(180),[0,0,1]);
      mMatrix = mat4.scale(mMatrix,[0.8,0.6,1.0]);
      mMatrix = mat4.translate(mMatrix,[0.62,1.47,0.0]);
      color = [0, 0.067, 0.722,1.0];
      pushMatrix(matrixStack,mMatrix);
      mMatrix = mat4.scale(mMatrix,[0.34,0.08,1.0]);
      mMatrix = mat4.translate(mMatrix,[-0.03,-2.3,0.0]);
      // color = [0.871, 0.871, 0.796,1.0];
      drawSquare(color,mMatrix);

      mMatrix = popMatrix(matrixStack);
      //triangle
      pushMatrix(matrixStack,mMatrix);
      mMatrix = mat4.scale(mMatrix,[0.086,0.086,1.0]);
      mMatrix = mat4.translate(mMatrix,[-2.17,-2.05,0.0]);
      mMatrix = mat4.rotate(mMatrix,degToRad(-63),[0,0,1]);
      mMatrix = mat4.translate(mMatrix,[0.0,0.34,0.0]);
      // color = [0.871, 0.871, 0.796,1.0];
      drawTriangle(color,mMatrix);
      mMatrix = popMatrix(matrixStack);

      pushMatrix(matrixStack,mMatrix);
      mMatrix = mat4.scale(mMatrix,[0.086,0.086,1.0]);
      mMatrix = mat4.translate(mMatrix,[1.82,-2.05,0.0]);
      mMatrix = mat4.rotate(mMatrix,degToRad(-63),[0,0,1]);
      mMatrix = mat4.translate(mMatrix,[0.0,0.3,0.0]);
      // color = [0.871, 0.871, 0.796,1.0];
      drawTriangle(color,mMatrix);
      mMatrix = popMatrix(matrixStack);

      mMatrix = popMatrix(matrixStack);

      mMatrix = popMatrix(matrixStack);

      animation = window.requestAnimationFrame(animate);
    }
    animate();
    //--------------------------------------------------------------------------

}
function webGLStart() {
    var canvas = document.getElementById("triangleRender");
    initGL(canvas);
    shaderProgram = initShaders();
  
    //get locations of attributes declared in the vertex shader
    const aPositionLocation = gl.getAttribLocation(shaderProgram, "aPosition");
  
    uMMatrixLocation = gl.getUniformLocation(shaderProgram, "uMMatrix");
  
    //enable the attribute arrays
    gl.enableVertexAttribArray(aPositionLocation);
  
    uColorLoc = gl.getUniformLocation(shaderProgram, "color");
  
    initSquareBuffer();
    initTriangleBuffer();
    initCircle();
  
    drawScene();
  }